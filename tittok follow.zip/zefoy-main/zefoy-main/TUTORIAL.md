# - C M D  S T E P S - 

## [ 1 ] - CHROMEDRIVER
- ### Go to - [chromedriver.chromium.org/downloads](https://chromedriver.chromium.org/downloads) - Download your version - [(Universal 99)](https://chromedriver.storage.googleapis.com/99.0.4844.51/chromedriver_win32.zip)
- ### See Chrome Version: go to chrome://settings/help
![image](https://user-images.githubusercontent.com/98614666/159102173-1bd3397e-7bb9-48be-8368-047655bb5789.png)
- ### Unzip - find chromedriver.exe
- ### Copy Paste in C:/ so the directory will be C:/chromedriver.exe
- 
## [ 2 ] - DOWNLOAD | PATH
- ### Download Code - click => [Here](https://github.com/xtekky/zefoy/archive/refs/tags/v6.0.1.zip) <=
- ### Unzip - Go to 'bots' File
![image](https://user-images.githubusercontent.com/98614666/159102405-3cca6ba7-917f-4b14-83a9-d73ba14e97bd.png)
- ### Copy File Path 
![image](https://user-images.githubusercontent.com/98614666/159102459-f8e3f277-fd39-4e11-bb11-42c4d974be69.png)

## [ 3 ] - DOWNLOADING LIBRARIES
- ### Open Command Prompt (CMD) and Paste:
```
pip install selenium
```
```
pip install pyfiglet
```
```
pip install chromedriver-autoinstaller
```
## [ 4 ] - RUNNING CODE
- ### Open Command Prompt (CMD)
- ### Type:
```
cd 'ctrl-v file path'
```
- ### Make sure that you have python installed - [Download](https://www.microsoft.com/en-us/p/python-310/9pjpw5ldxlz5#activetab=pivot:overviewtab)
- ### Then Type (For v6):
```
python zefoy-v6.py
```
- ### ENTER
- ### You should see this (for v.6 only URL):
![image](https://user-images.githubusercontent.com/98614666/159102779-8dc8dd21-fc4d-46d3-8bb6-a5f43cce5a09.png)

## [ 5 ] - FINAL STEPS
- ### Copy and Paste TikTok Url:
![image](https://user-images.githubusercontent.com/98614666/159102913-185b0bab-7158-4076-88d9-fc0d79c6ccf4.png)
- ### Copy and Paste chromedriver.exe PATH (C:/chromedriver.exe):
```
C:/chromedriver.exe
```
![image](https://user-images.githubusercontent.com/98614666/159102998-7ece5ad1-c7b9-4503-8975-92b41bf193c1.png)
- ### SOLVE CAPTCHA FAST ON POP-UP
![image](https://user-images.githubusercontent.com/98614666/159103044-c5928d97-dce0-4a65-ae67-4803a9b764f5.png)
- ### DONE! - You need to keep the script running, you can minimize the windos - ENJOY!
- ### Subscribe to my github [@xtekky](https://github.com/xtekky)







