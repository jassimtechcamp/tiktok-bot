## IF YOU WANT TO CONTRIBUTE CONTACT ME AT:
- 📫 Discord: [xtekky#9031](https://discord.gg/)
- 📲 Telegram: [t.me/xtekky](https://t.me/xtekky)
